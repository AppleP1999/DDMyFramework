//
//  MenusModel.m
//  
//
//  Created by apple-jd33 on 15/11/18.
//  Copyright © 2015年 HansRove. All rights reserved.
//

#import "MenusModel.h"

@implementation MenusModel


+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [MenuLists class]};
}
@end
@implementation MenuLists

@end



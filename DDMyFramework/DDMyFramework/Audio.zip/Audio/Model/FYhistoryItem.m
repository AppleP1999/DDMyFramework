//
//  FYhistoryItem.m
//  music
//
//  Created by 寿煜宇 on 16/6/10.
//  Copyright © 2016年 Fyus. All rights reserved.
//

#import "FYhistoryItem.h"

@implementation FYhistoryItem

// Insert code here to add functionality to your managed object subclass

@end

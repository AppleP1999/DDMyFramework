//
//  SpecialModel.m
//  
//
//  Created by apple-jd33 on 15/11/21.
//  Copyright © 2015年 HansRove. All rights reserved.
//

#import "SpecialModel.h"

@implementation SpecialModel
+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [SpecialMoreList class]};
}
@end
@implementation SpecialMoreList

@end

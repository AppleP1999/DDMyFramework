//
//  FYfavoriteItem.m
//  music
//
//  Created by 寿煜宇 on 16/6/10.
//  Copyright © 2016年 Fyus. All rights reserved.
//

#import "FYfavoriteItem.h"

@implementation FYfavoriteItem

// Insert code here to add functionality to your managed object subclass

@end

//
//  ContentCategoryModel.m
//  
//
//  Created by apple-jd33 on 15/11/19.
//  Copyright © 2015年 HansRove. All rights reserved.
//

#import "ContentCategoryModel.h"

@implementation ContentCategoryModel


+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [CategoryList class]};
}
@end
@implementation CategoryList

@end



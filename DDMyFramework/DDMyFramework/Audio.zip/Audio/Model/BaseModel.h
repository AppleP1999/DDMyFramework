//
//  BaseModel.h
//  
//
//  Created by apple-jd33 on 15/11/9.
//  Copyright © 2015年 HansRove. All rights reserved.
//  用的是封装好的接口

#import <Foundation/Foundation.h>

@interface BaseModel : NSObject

@end

//
//  DestinationModel.m
//  
//
//  Created by apple-jd33 on 15/11/23.
//  Copyright © 2015年 HansRove. All rights reserved.
//

#import "DestinationModel.h"

@implementation DestinationModel

@end
@implementation DAlbum

@end


@implementation DTracks

+ (NSDictionary *)objectClassInArray{
    return @{@"list" : [DTracks_List class]};
}

@end


@implementation DTracks_List

@end



//
//  FCRollingView.h
//  DDMyFramework
//
//  Created by omni－appple on 2019/6/20.
//  Copyright © 2019年 COM.Sobey.dengjie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FCRollingView : UIView
+(FCRollingView* ) rollingWithButtomView:(UIView*)buttomView  size:(CGSize)size;
 
- (void)drawProgress:(CGFloat )progress;
- (void)takeBack;

@property (nonatomic, strong) UIImageView *img_bgView ;
@end


@interface FCRollingBGView : UIView
@property (nonatomic,strong) FCRollingView  * topView;
@property (nonatomic, strong) UIButton *btn_bg ;

@end
